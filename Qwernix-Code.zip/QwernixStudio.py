import os
import sys
import io
import runpy
import threading
from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.core.window import Window

# Тёмная тема для мобильного экрана
Window.clearcolor = (0.11, 0.12, 0.15, 1)

TARGET_FILE = "main.qwnx"

# Палитра готовых блоков из документации Qwernix v2.34.0
QWERNIX_BLOCKS = [
    ("Set (Переменная)", '[Set Hero = Скибиди]'),
    ("Print (Вывод)", '[Print("Привет, {Hero}!")]'),
    ("Color (Цвет)", '[Color(cyan)]'),
    ("Calculate (Математика)", '[Calculate Res = 10 + 5 * 2]'),
    ("Random (Случайное)", '[Random(1, 100 -> Roll)]'),
    ("If / Else (Условие)", '[If {Roll} > 50 Then Print("Победа!") Else Print("Промах!")]'),
    ("For (Цикл)", '[For i = 1 To 3 Do Print("Шаг {i}")]'),
    ("Sleep (Пауза 1с)", '[Sleep(1.0)]'),
    ("Dict (Словарь)", '[DictCreate(-> Bag)] [DictSet(Bag, "Item", "Базука")]'),
    ("AIUse (Локальный ИИ)", '[Set AI_Mode = dialog] [AIUse(Request = "Привет!", MaxTokens = 30, -> Reply)] [Print("{Reply}")]'),
]


class QwernixStudio(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=10, spacing=8, **kwargs)
        self.is_running = False

        # 1. Заголовок
        header = Label(
            text=f"[b]QWERNIX v2.34.0 — VISUAL STUDIO ({TARGET_FILE})[/b]",
            markup=True,
            size_hint_y=None,
            height=40,
            color=(0.3, 0.85, 1, 1)
        )
        self.add_widget(header)

        # 2. Палитра блоков
        palette_label = Label(
            text="Нажми на блок, чтобы добавить его в код:",
            size_hint_y=None,
            height=24,
            font_size="13sp",
            color=(0.7, 0.7, 0.75, 1)
        )
        self.add_widget(palette_label)

        palette_scroll = ScrollView(size_hint_y=None, height=110, do_scroll_x=True, do_scroll_y=False)
        palette_grid = GridLayout(rows=2, spacing=6, size_hint_x=None)
        palette_grid.bind(minimum_width=palette_grid.setter("width"))

        for title, snippet in QWERNIX_BLOCKS:
            btn = Button(
                text=title,
                size_hint_x=None,
                width=180,
                background_color=(0.2, 0.35, 0.55, 1),
                font_size="13sp"
            )
            btn.bind(on_release=lambda instance, code=snippet: self.add_block(code))
            palette_grid.add_widget(btn)

        palette_scroll.add_widget(palette_grid)
        self.add_widget(palette_scroll)

        # 3. Загружаем main.qwnx, если он уже есть на диске
        initial_code = '# Собери программу из блоков выше!\n[Set User = Огайо]\n[Print("Запуск Qwernix для {User}...")]\n'
        if os.path.exists(TARGET_FILE):
            try:
                with open(TARGET_FILE, "r", encoding="utf-8") as f:
                    saved = f.read()
                    if saved.strip():
                        initial_code = saved
            except Exception:
                pass

        self.code_editor = TextInput(
            text=initial_code,
            font_size="14sp",
            background_color=(0.16, 0.17, 0.21, 1),
            foreground_color=(0.95, 0.95, 0.95, 1),
            cursor_color=(0.3, 0.85, 1, 1),
            size_hint_y=0.45
        )
        self.add_widget(self.code_editor)

        # 4. Панель управления (Запуск / Сохранить в main.qwnx / Очистить)
        controls = BoxLayout(size_hint_y=None, height=48, spacing=6)

        self.run_btn = Button(
            text="▶ ЗАПУСТИТЬ",
            size_hint_x=0.45,
            background_color=(0.15, 0.65, 0.35, 1),
            bold=True
        )
        self.run_btn.bind(on_release=self.start_execution)

        save_btn = Button(
            text="💾 Сохранить",
            size_hint_x=0.30,
            background_color=(0.2, 0.5, 0.75, 1)
        )
        save_btn.bind(on_release=self.save_only)

        clear_btn = Button(
            text="Очистить",
            size_hint_x=0.25,
            background_color=(0.55, 0.2, 0.25, 1)
        )
        clear_btn.bind(on_release=lambda _: setattr(self.code_editor, "text", ""))

        controls.add_widget(self.run_btn)
        controls.add_widget(save_btn)
        controls.add_widget(clear_btn)
        self.add_widget(controls)

        # 5. Консоль вывода (отдельный поток)
        console_label = Label(
            text="Консоль выполнения (отдельный поток):",
            size_hint_y=None,
            height=24,
            font_size="13sp",
            color=(0.7, 0.7, 0.75, 1)
        )
        self.add_widget(console_label)

        self.console_out = TextInput(
            text=f"Готов к работе с {TARGET_FILE}...\n",
            readonly=True,
            font_size="13sp",
            background_color=(0.07, 0.08, 0.1, 1),
            foreground_color=(0.4, 0.95, 0.5, 1),
            size_hint_y=0.35
        )
        self.add_widget(self.console_out)

    def add_block(self, snippet: str):
        current = self.code_editor.text
        if current and not current.endswith("\n"):
            current += "\n"
        self.code_editor.text = current + snippet + "\n"

    def save_to_file(self) -> bool:
        """Сохраняет текст из редактора в main.qwnx."""
        try:
            with open(TARGET_FILE, "w", encoding="utf-8") as f:
                f.write(self.code_editor.text)
            return True
        except Exception as e:
            self.log_ui(f"[ОШИБКА СОХРАНЕНИЯ {TARGET_FILE}]: {e}\n")
            return False

    def save_only(self, instance):
        if self.save_to_file():
            self.log_ui(f"[💾] Код успешно сохранён в {TARGET_FILE}\n")

    def log_ui(self, text: str):
        def _append(dt):
            self.console_out.text += text
            self.console_out.cursor = (0, len(self.console_out.text))
        Clock.schedule_once(_append, 0)

    def start_execution(self, instance):
        if self.is_running:
            self.log_ui("[!] Скрипт уже выполняется в фоне...\n")
            return

        if not self.code_editor.text.strip():
            return

        if not self.save_to_file():
            return

        self.is_running = True
        self.run_btn.text = "⏳ РАБОТАЕТ..."
        self.run_btn.disabled = True
        self.console_out.text = f"--- Сохранено в {TARGET_FILE} | Старт потока Qwernix ---\n"

        worker_thread = threading.Thread(
            target=self._run_qwernix_worker,
            args=(TARGET_FILE,),
            daemon=True
        )
        worker_thread.start()

    def _run_qwernix_worker(self, qwnx_filepath: str):
        class LiveStream(io.TextIOBase):
            def __init__(self, callback):
                self.callback = callback

            def write(self, s):
                if s:
                    self.callback(s)
                return len(s)

        old_stdout, old_stderr = sys.stdout, sys.stderr
        old_argv = sys.argv[:]
        live_out = LiveStream(self.log_ui)

        try:
            sys.stdout = live_out
            sys.stderr = live_out

            if os.path.exists("qwernix.py"):
                sys.argv = ["qwernix.py", qwnx_filepath]
                runpy.run_path("qwernix.py", run_name="__main__")
            else:
                self.log_ui(
                    f"[INFO] Файл qwernix.py не найден рядом, но код сохранён в {qwnx_filepath}:\n\n"
                    f"{self.code_editor.text}\n"
                )

        except SystemExit as e:
            self.log_ui(f"\n[Qwernix завершён с кодом {e.code}]\n")
        except Exception as e:
            self.log_ui(f"\n[ОШИБКА ВЫПОЛНЕНИЯ]: {e}\n")
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            sys.argv = old_argv
            Clock.schedule_once(self._finish_execution, 0)

    def _finish_execution(self, dt):
        self.is_running = False
        self.run_btn.text = "▶ ЗАПУСТИТЬ"
        self.run_btn.disabled = False
        self.log_ui("--- Поток завершён ---\n")


class QwernixBlockApp(App):
    def build(self):
        self.title = "Qwernix Block Studio"
        return QwernixStudio()


if __name__ == "__main__":
    QwernixBlockApp().run()
