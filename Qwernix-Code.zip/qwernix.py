# ============================================================
# Qwernix v2.35.0 (NABAAT / TCNATT Integrated + Network/Async)
# ============================================================
import re
import os
import sys
import time
import math
import random
import glob
import zipfile
import platform as _platform
import threading
import subprocess
import base64 as _b64
import hashlib as _hashlib
import uuid as _uuid
import shutil as _shutil
from datetime import datetime as _datetime, timedelta as _timedelta
from urllib.request import urlopen as _urlopen, Request as _urlRequest, urlretrieve as _urlretrieve
from urllib.parse import quote as _urlquote, unquote as _urlunquote

# ============================================================
# 🚀 CPU SETUP
# ============================================================
os.environ["OPENBLAS_NUM_THREADS"] = "6"
os.environ["OMP_NUM_THREADS"] = "6"
os.environ["MKL_NUM_THREADS"] = "6"

try:
    import numpy as np
except ImportError:
    print("⚠️ NumPy не установлен. AIUse будет недоступен.")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

qwernix_variables = {
    "Execution_Qwernix_Ver": "Qwernix v2.35.0 (NABAAT Integrated)",
    "VERSION": "Qwernix v2.35.0",
    "SCRIPT_VERSION": "2.35.0",
    "PLATFORM": sys.platform,
    "OS_ARCH": _platform.machine(),
    "TRUE": "1",
    "FALSE": "0",
    "PI": "3.1415926535",
    "E": "2.7182818284",
    "Iteration_Limit": "100000",
    "AI_Model": "MegixMXI",
    "AI_Mode": "continue",
    "AI_Heads": "4",
    "IS_ASYNC_ENABLED": "1",
    "AI_STREAM_MODE": "off",
}

qwernix_custom_functions = {}
qwernix_timers = {}
qwernix_traces = False
qwernix_loaded_modules = {}
_import_stack = set()
_current_line = 0
_try_depth = 0

# Sandbox / async state
_sandbox_deadline = None
_sandbox_start = None
_sandbox_memory_limit = None
_ai_threads = {}

RESET  = "\033[0m"
RED    = "\033[31m"
GREEN  = "\033[32m"
YELLOW = "\033[33m"
CYAN   = "\033[36m"

def error(msg):
    if _try_depth > 0:
        raise RuntimeError(msg)
    print(f"{RED}Qwernix Error (line {_current_line}): {msg}{RESET}")

def warning(msg):
    print(f"{YELLOW}Qwernix Warning (line {_current_line}): {msg}{RESET}")

def _fail(msg):
    if _try_depth > 0:
        raise RuntimeError(msg)
    error(msg)

# =============== PARSERS ===============
def unquote(s):
    s = s.strip()
    if len(s) >= 2 and ((s[0] == '"' and s[-1] == '"') or (s[0] == "'" and s[-1] == "'")):
        return s[1:-1]
    return s

def smart_split(s, sep=','):
    parts, current, in_quote, depth = [], [], None, 0
    for ch in s:
        if in_quote:
            current.append(ch)
            if ch == in_quote: in_quote = None
        elif ch in ('"', "'"):
            current.append(ch); in_quote = ch
        elif ch in '([{':
            depth += 1; current.append(ch)
        elif ch in ')]}':
            depth -= 1; current.append(ch)
        elif ch == sep and depth == 0:
            parts.append(''.join(current).strip()); current = []
        else:
            current.append(ch)
    parts.append(''.join(current).strip())
    return parts

def split_args(raw): return [unquote(p) for p in smart_split(raw)]
def split_commands(s): return [p for p in smart_split(s, ';') if p]

def split_arrow(args):
    in_quote = None
    i = 0
    while i < len(args) - 1:
        ch = args[i]
        if in_quote:
            if ch == in_quote: in_quote = None
            i += 1
        elif ch in ('"', "'"):
            in_quote = ch; i += 1
        elif args[i:i+2] == "->":
            return args[:i].strip(), args[i+2:].strip()
        else:
            i += 1
    return args.strip(), None

def extract_blocks(line):
    blocks, current, in_quote, depth, started = [], [], None, 0, False
    for ch in line:
        if in_quote:
            current.append(ch)
            if ch == in_quote: in_quote = None
        elif ch in ('"', "'"):
            if started: current.append(ch)
            in_quote = ch
        elif ch == '[':
            if not started:
                started, current, depth = True, ['['], 1
            else:
                depth += 1; current.append(ch)
        elif ch == ']':
            if started:
                depth -= 1; current.append(ch)
                if depth == 0:
                    blocks.append(''.join(current)); current, started = [], False
        elif started:
            current.append(ch)
    return blocks

# =============== SUBSTITUTIONS ===============
def substitute_vars(text):
    def repl(m):
        name = m.group(1)
        if name in qwernix_variables:
            val = qwernix_variables[name]
            if isinstance(val, list): return "[" + ", ".join(str(x) for x in val) + "]"
            if isinstance(val, dict): return "{" + ", ".join(f"{k}: {v}" for k, v in val.items()) + "}"
            return str(val)
        return m.group(0)
    return re.sub(r'\{(\w+)\}', repl, text)

def substitute_args(text, local_args):
    if not local_args: return text
    def repl(m):
        idx = int(m.group(1)) - 1
        if 0 <= idx < len(local_args): return str(local_args[idx])
        return m.group(0)
    return re.sub(r'\$(\d+)', repl, text)

def replace_identifiers(expr):
    def repl(m):
        name = m.group(0)
        if name in qwernix_variables and not isinstance(qwernix_variables[name], (list, dict)):
            return str(qwernix_variables[name])
        return name
    return re.sub(r'[A-Za-z_]\w*', repl, expr)

def eval_arith(expr):
    replaced = replace_identifiers(expr)
    safe = re.sub(r'[^0-9+\-*/()%\s.]', '', replaced)
    if not safe.strip(): return None
    try: return eval(safe)
    except Exception: return None

# =============== CONDITIONS ===============
def evaluate_single_condition(sub_cond):
    sub_cond = sub_cond.strip()
    if sub_cond.upper().startswith("NOT "):
        return not evaluate_single_condition(sub_cond[4:].strip())
    m = re.match(r'(.+?)\s*(==|!=|>=|<=|>|<)\s*(.+)', sub_cond)
    if not m:
        val = sub_cond.strip().strip('"\'')
        if val.lower() in ("true", "1"): return True
        if val.lower() in ("false", "0", ""): return False
        try: return float(val) != 0
        except ValueError: return bool(val)
    left = m.group(1).strip().strip('"\'')
    op = m.group(2)
    right = m.group(3).strip().strip('"\'')
    try:
        ln, rn = float(left), float(right)
        return {"==": ln == rn, "!=": ln != rn, ">": ln > rn, "<": ln < rn, ">=": ln >= rn, "<=": ln <= rn}[op]
    except ValueError:
        return {"==": left == right, "!=": left != right, ">": left > right, "<": left < right, ">=": left >= right, "<=": left <= right}[op]

def evaluate_condition(cond):
    cond = cond.strip()
    if " OR " in cond: return any(evaluate_condition(p.strip()) for p in cond.split(" OR "))
    if " AND " in cond: return all(evaluate_condition(p.strip()) for p in cond.split(" AND "))
    return evaluate_single_condition(cond)

def parse_and_eval_condition(cond, local_args=None):
    if local_args: cond = substitute_args(cond, local_args)
    return evaluate_condition(substitute_vars(cond))

# =============== BLOCK EXECUTION ===============
def execute_qwernix_block(block_str, local_args=None):
    for cmd in split_commands(block_str):
        if not cmd: continue
        if not cmd.startswith("["): cmd = "[" + cmd
        if not cmd.endswith("]"): cmd = cmd + "]"
        sig = execute_qwernix_line(cmd, local_args)
        if sig == "break": return "break"
        if sig == "continue": return "continue"
        if isinstance(sig, tuple) and sig[0] == "return": return sig
    return None

def get_iteration_limit():
    try:
        lim = int(float(qwernix_variables.get("Iteration_Limit", 100000)))
        if lim <= 0:
            warning("Iteration_Limit ≤ 0 — откат к 100000"); return 100000
        return lim
    except (ValueError, TypeError):
        warning("Iteration_Limit не число — откат к 100000"); return 100000

def handle_while(cond_raw, action_raw, local_args):
    safety, limit = 0, get_iteration_limit()
    while parse_and_eval_condition(cond_raw, local_args):
        sig = execute_qwernix_block(action_raw, local_args)
        if sig == "break": break
        if sig == "continue": continue
        if isinstance(sig, tuple) and sig[0] == "return": return sig
        safety += 1
        if safety >= limit:
            error(f"Превышен Iteration_Limit ({limit})"); break
    return None

def handle_for(start_raw, end_raw, step_raw, var_name, action_raw, local_args):
    try:
        start = float(eval_arith(substitute_args(start_raw, local_args)) or 0)
        end = float(eval_arith(substitute_args(end_raw, local_args)) or 0)
        step = float(eval_arith(substitute_args(step_raw, local_args)) or 1) if step_raw else 1.0
    except Exception:
        error(f"For: не числа ({start_raw}, {end_raw}, {step_raw})"); return None
    if step == 0: error("For: Step не может быть 0"); return None
    safety, limit = 0, get_iteration_limit()
    i = start
    while (step > 0 and i <= end) or (step < 0 and i >= end):
        qwernix_variables[var_name] = str(int(i)) if i == int(i) else str(i)
        sig = execute_qwernix_block(action_raw, local_args)
        if sig == "break": break
        if sig == "continue":
            i += step; safety += 1
            if safety >= limit: error(f"Превышен Iteration_Limit ({limit})"); break
            continue
        if isinstance(sig, tuple) and sig[0] == "return": return sig
        i += step; safety += 1
        if safety >= limit: error(f"Превышен Iteration_Limit ({limit})"); break
    return None

def handle_foreach(var_name, list_name, action_raw, local_args):
    lst = qwernix_variables.get(list_name)
    if not isinstance(lst, list): error(f"ForEach: '{list_name}' не список"); return None
    safety, limit = 0, get_iteration_limit()
    for item in lst:
        qwernix_variables[var_name] = str(item)
        sig = execute_qwernix_block(action_raw, local_args)
        if sig == "break": break
        if sig == "continue": continue
        if isinstance(sig, tuple) and sig[0] == "return": return sig
        safety += 1
        if safety >= limit: error(f"Превышен Iteration_Limit ({limit})"); break
    return None

def handle_if(cond_raw, then_raw, else_raw, local_args):
    if parse_and_eval_condition(cond_raw, local_args): return execute_qwernix_block(then_raw, local_args)
    if else_raw is not None:
        if else_raw.strip().startswith("If "): return execute_qwernix_line(f"[{else_raw.strip()}]", local_args)
        return execute_qwernix_block(else_raw, local_args)
    return None

def handle_try(try_raw, catch_var, catch_raw, local_args, finally_raw=None):
    global _current_line, _try_depth
    saved = _current_line
    _try_depth += 1
    try:
        return execute_qwernix_block(try_raw, local_args)
    except Exception as e:
        _current_line = saved
        qwernix_variables[catch_var] = str(e)
        if catch_raw: return execute_qwernix_block(catch_raw, local_args)
    finally:
        _current_line = saved
        _try_depth -= 1
        if finally_raw:
            try: execute_qwernix_block(finally_raw, local_args)
            except Exception as fe: error(f"Finally: {fe}")
    return None

# =============== IMPORT SYSTEM ===============
KITS = {
    "base":   ["json", "math", "random", "time", "re", "numpy"],
    "system": ["os", "sys", "subprocess", "glob", "pathlib"],
    "files":  ["zipfile", "shutil", "base64", "hashlib"],
}
KITS["all"] = KITS["base"] + KITS["system"] + KITS["files"]

def run_import_qwnx(lib_name, local_args):
    global _current_line
    path = lib_name if lib_name.endswith(".qwnx") else lib_name + ".qwnx"
    if not os.path.isabs(path): path = os.path.join(SCRIPT_DIR, path)
    if not os.path.exists(path): error(f"Библиотека '{path}' не найдена"); return None
    if path in _import_stack: error(f"Циклический импорт '{path}'"); return None
    saved = _current_line
    _import_stack.add(path)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for i, lib_line in enumerate(f, 1):
                _current_line = i
                sig = execute_qwernix_line(lib_line, local_args)
                if sig: return sig
    finally:
        _import_stack.discard(path); _current_line = saved
    return None

def run_import_py(module_name):
    if module_name in qwernix_loaded_modules: return None
    try:
        mod = __import__(module_name)
        qwernix_loaded_modules[module_name] = mod
        return None
    except ImportError as e:
        error(f"Python-модуль '{module_name}' не найден: {e}"); return None

def run_import_kit(kit_name):
    key = kit_name.lower().replace("-kit", "").strip()
    if key not in KITS: error(f"Неизвестный Kit '{kit_name}'. Доступны: {list(KITS.keys())}"); return None
    for mod in KITS[key]: run_import_py(mod)
    return None

# =============== MEGIX LOCAL LOADER (TCNATT Support) ===============
class MegixLocal:
    def __init__(self, model_dir):
        files = os.listdir(model_dir)
        npz_files = [f for f in files if f.endswith('.npz')]
        txt_files = [f for f in files if f.endswith('.txt')]
        if not npz_files or not txt_files:
            raise FileNotFoundError(f"Нет .npz или .txt в {model_dir}")

        npz_path = os.path.join(model_dir, next((f for f in npz_files if 'memory' in f or 'brain' in f), npz_files[0]))
        vocab_path = os.path.join(model_dir, next((f for f in txt_files if 'vocab' in f), txt_files[0]))

        self.weights = dict(np.load(npz_path, allow_pickle=False))
        with open(vocab_path, encoding='utf-8') as f:
            self.vocab = [w.rstrip('\n') for w in f]

        self.word_to_idx = {w: i for i, w in enumerate(self.vocab)}
        self.idx_to_word = self.vocab
        self.unk_idx = self.word_to_idx.get('<unk>', 1)
        self.pad_idx = self.word_to_idx.get('<pad>', 0)
        self.eos_idx = self.word_to_idx.get('<eos>', -1)

        if 'TCN0_W' in self.weights:
            self.arch = 'tcnatt'
        elif 'model_type' in self.weights:
            mt = self.weights['model_type']
            self.arch = str(mt) if not hasattr(mt, 'item') else str(mt.item())
        elif 'E' in self.weights or 'P_E' in self.weights:
            self.arch = 'gru'
        elif 'P_tok_emb' in self.weights or 'tok_emb' in self.weights:
            self.arch = 'transformer'
        else:
            raise ValueError(f"Неизвестная архитектура: {list(self.weights.keys())[:5]}")

        self.total_params = sum(v.size for k, v in self.weights.items() if not k.endswith('_c') and k not in ('epoch', 'adam_t'))

    def _get(self, key):
        if key in self.weights: return self.weights[key]
        if f'P_{key}' in self.weights: return self.weights[f'P_{key}']
        raise KeyError(key)

    def _has(self, key):
        return key in self.weights or f'P_{key}' in self.weights

    def _gru_forward(self, tokens):
        E = self._get('E')
        p1 = [self._get(k) for k in ['Wz1','Uz1','bz1','Wr1','Ur1','br1','Wh1','Uh1','bh1']]
        p2 = [self._get(k) for k in ['Wz2','Uz2','bz2','Wr2','Ur2','br2','Wh2','Uh2','bh2']]
        Why, by = self._get('Why'), self._get('by')
        def sig(x): return 1.0/(1.0+np.exp(-np.clip(x,-30,30)))
        def gru(x, h, p):
            Wz,Uz,bz,Wr,Ur,br,Wh,Uh,bh = p
            z = sig(Wz@x + Uz@h + bz)
            r = sig(Wr@x + Ur@h + br)
            ht = np.tanh(Wh@x + Uh@(r*h) + bh)
            return (1-z)*h + z*ht
        h1, h2 = np.zeros((p1[0].shape[0], 1), np.float32), np.zeros((p2[0].shape[0], 1), np.float32)
        out = []
        for t in tokens:
            h1 = gru(E[:, t:t+1], h1, p1)
            h2 = gru(h1, h2, p2)
            out.append((Why @ h2 + by).flatten())
        return np.array(out)

    def _transformer_forward(self, tokens, n_heads=4):
        tok_emb = self._get('tok_emb')
        V, D = tok_emb.shape
        dh = D // n_heads
        T = len(tokens)
        x = tok_emb[tokens].astype(np.float32)
        has_pos = self._has('pos_emb')
        if has_pos: x = x + self._get('pos_emb')[:T]
        use_rope = not has_pos
        n_layers = 0
        while self._has(f'L{n_layers}_Wq'): n_layers += 1
        mask = (np.triu(np.ones((T,T), np.float32), k=1) * -1e9)[None, :, :]
        if use_rope:
            freqs = 1.0 / (10000 ** (np.arange(0, dh, 2) / dh))
            angles = np.arange(T)[:, None] * freqs[None, :]
            cos, sin = np.cos(angles).astype(np.float32), np.sin(angles).astype(np.float32)
        def rope_apply(xx):
            x1, x2 = xx[..., 0::2], xx[..., 1::2]
            c, s = cos[None, :, :], sin[None, :, :]
            out = np.empty_like(xx)
            out[..., 0::2] = x1 * c - x2 * s
            out[..., 1::2] = x1 * s + x2 * c
            return out
        def ln(xx, g, b):
            mu, var = xx.mean(-1, keepdims=True), xx.var(-1, keepdims=True)
            return g * (xx - mu) / np.sqrt(var + 1e-5) + b
        for l in range(n_layers):
            Wq, Wk, Wv, Wo = self._get(f'L{l}_Wq'), self._get(f'L{l}_Wk'), self._get(f'L{l}_Wv'), self._get(f'L{l}_Wo')
            ln1g, ln1b = self._get(f'L{l}_ln1_g'), self._get(f'L{l}_ln1_b')
            W1, b1, W2, b2 = self._get(f'L{l}_W1'), self._get(f'L{l}_b1'), self._get(f'L{l}_W2'), self._get(f'L{l}_b2')
            ln2g, ln2b = self._get(f'L{l}_ln2_g'), self._get(f'L{l}_ln2_b')
            h1 = ln(x, ln1g, ln1b)
            Q = (h1 @ Wq).reshape(T, n_heads, dh).transpose(1,0,2)
            K = (h1 @ Wk).reshape(T, n_heads, dh).transpose(1,0,2)
            Vv = (h1 @ Wv).reshape(T, n_heads, dh).transpose(1,0,2)
            if use_rope: Q, K = rope_apply(Q), rope_apply(K)
            scores = Q @ K.transpose(0,2,1) / np.sqrt(dh) + mask
            m = scores.max(-1, keepdims=True)
            e = np.exp(scores - m)
            attn = e / e.sum(-1, keepdims=True)
            x = x + (attn @ Vv).transpose(1,0,2).reshape(T, D) @ Wo
            h2 = ln(x, ln2g, ln2b)
            x = x + np.maximum(0, h2 @ W1 + b1) @ W2 + b2
        xf = ln(x, self._get('lnf_g'), self._get('lnf_b'))
        Wout = self._get('Wout') if self._has('Wout') else tok_emb.T
        return xf @ Wout + self._get('bout')

    def _tcnatt_forward(self, tokens):
        tok_emb = self._get('E')
        V, EMBED_DIM = tok_emb.shape
        HIDDEN = self._get('TCN0_W').shape[2]
        n_heads = int(qwernix_variables.get("AI_Heads", 4))
        X = np.array(tokens, np.int64)[None, :]
        B, T = X.shape
        x_emb = tok_emb[X]
        def layernorm(x, g, b, eps=1e-5):
            mu, var = x.mean(axis=-1, keepdims=True), x.var(axis=-1, keepdims=True)
            return g * (x - mu) / np.sqrt(var + eps) + b
        def conv1d(x, W, b, dilation):
            batch, seq, in_c = x.shape
            kernel, _, out_c = W.shape
            pad = (kernel - 1) * dilation
            x_pad = np.pad(x, ((0, 0), (pad, 0), (0, 0))) if pad > 0 else x
            cols = np.stack([x_pad[:, i * dilation: i * dilation + seq, :] for i in range(kernel)], axis=2)
            cols_2d = cols.reshape(batch * seq, kernel * in_c)
            out_2d = cols_2d @ W.reshape(kernel * in_c, out_c) + b
            return out_2d.reshape(batch, seq, out_c)
        def mha(x, Wq, Wk, Wv, Wo):
            B_, T_, D_ = x.shape
            dh = D_ // n_heads
            Q, K, V_ = x @ Wq, x @ Wk, x @ Wv
            def split(X_): return X_.reshape(B_, T_, n_heads, dh).transpose(0, 2, 1, 3)
            Qh, Kh, Vh = split(Q), split(K), split(V_)
            mask = np.triu(np.ones((T_, T_), np.float32), k=1)[None, None, :, :] * -1e9
            scores = np.einsum('bhqd,bhkd->bhqk', Qh, Kh) / np.sqrt(dh) + mask
            m = scores.max(axis=-1, keepdims=True)
            e = np.exp(scores - m)
            attn = e / e.sum(axis=-1, keepdims=True)
            out_h = np.einsum('bhqk,bhkd->bhqd', attn, Vh)
            return out_h.transpose(0, 2, 1, 3).reshape(B_, T_, D_) @ Wo
        h0 = conv1d(x_emb, self._get('TCN0_W'), self._get('TCN0_b'), 1)
        h_ln0 = layernorm(h0, self._get('TCN0_ln_g'), self._get('TCN0_ln_b'))
        h_act0 = np.maximum(0, h_ln0)
        x_tcn1 = x_emb + h_act0 if x_emb.shape[-1] == h_act0.shape[-1] else h_act0
        h1 = conv1d(x_tcn1, self._get('TCN1_W'), self._get('TCN1_b'), 2)
        h_ln1 = layernorm(h1, self._get('TCN1_ln_g'), self._get('TCN1_ln_b'))
        h_act1 = np.maximum(0, h_ln1)
        x_tcn2 = x_tcn1 + h_act1
        att = mha(x_tcn2, self._get('Att_Wq'), self._get('Att_Wk'), self._get('Att_Wv'), self._get('Att_Wo'))
        x_ln_att = layernorm(att, self._get('Att_ln_g'), self._get('Att_ln_b'))
        x_attn = x_tcn2 + x_ln_att
        ffn_h1 = x_attn @ self._get('FFN_W1') + self._get('FFN_b1')
        ffn_h1_act = np.maximum(0, ffn_h1)
        ffn_h2 = ffn_h1_act @ self._get('FFN_W2') + self._get('FFN_b2')
        ffn_ln = layernorm(ffn_h2, self._get('FFN_ln_g'), self._get('FFN_ln_b'))
        x_out = x_attn + ffn_ln
        logits = x_out.reshape(B*T, HIDDEN) @ self._get('Why').T + self._get('by').T
        return logits.reshape(T, -1)

    def _forward(self, seq_ids, n_heads=4):
        seq_ids = seq_ids[-64:]
        if self.arch == 'gru': return self._gru_forward(seq_ids)
        if self.arch == 'tcnatt': return self._tcnatt_forward(seq_ids)
        return self._transformer_forward(seq_ids, n_heads)

    def generate(self, prompt_tokens, max_tokens=40, temp=0.85, n_heads=4, callback=None):
        ids = [self.word_to_idx.get(t, self.unk_idx) for t in prompt_tokens] or [self.unk_idx]
        start_len = len(ids)
        user_idx = self.word_to_idx.get('<user>', -1)
        bot_idx = self.word_to_idx.get('<bot>', -1)
        rep_penalty = 1.5
        top_k = 3
        for _ in range(max_tokens):
            last_logits = self._forward(ids, n_heads)[-1].astype(np.float64).copy()
            for tid in set(ids[-10:]):
                if last_logits[tid] > 0: last_logits[tid] /= rep_penalty
                else: last_logits[tid] *= rep_penalty
            if 0 <= self.pad_idx < len(last_logits): last_logits[self.pad_idx] = -1e9
            if 0 <= self.unk_idx < len(last_logits): last_logits[self.unk_idx] = -1e9
            if 0 <= user_idx < len(last_logits): last_logits[user_idx] = -1e9
            if 0 <= bot_idx < len(last_logits): last_logits[bot_idx] = -1e9
            t_val = max(temp, 1e-5)
            last_logits /= t_val
            if top_k > 0:
                mask = np.full_like(last_logits, -1e9)
                top_indices = np.argsort(last_logits)[-top_k:]
                mask[top_indices] = last_logits[top_indices]
                last_logits = mask
            probs = np.exp(last_logits - np.max(last_logits))
            probs /= probs.sum()
            next_token = int(np.random.choice(len(probs), p=probs))
            w = self.idx_to_word[next_token]
            if next_token == self.eos_idx or w in ('<user>', '<bot>', '<pad>'):
                break
            ids.append(next_token)
            if callback:
                try: callback(w)
                except Exception: pass
        return [self.idx_to_word[i] for i in ids[start_len:]]

    def embed(self, tokens):
        """Среднее эмбеддингов по токенам. Экспериментально."""
        if 'E' not in self.weights:
            raise RuntimeError("embed: нет матрицы E")
        E = self.weights['E']
        ids = [self.word_to_idx.get(t, self.unk_idx) for t in tokens]
        if not ids: return np.zeros(E.shape[1] if E.ndim == 2 else E.shape[0], np.float32)
        # TCNATT: E = (V, D); GRU: E = (D, V)
        if E.shape[0] > E.shape[1]:
            return E[ids].mean(axis=0).astype(np.float32)
        return E[:, ids].mean(axis=1).astype(np.float32)

_megix_cache = {}

def get_megix_model(model_name=None):
    if model_name is None:
        model_name = qwernix_variables.get("AI_Model", "MegixMXI")
    if model_name in _megix_cache: return _megix_cache[model_name]
    base = os.path.join(SCRIPT_DIR, "MegixModels")
    if not os.path.isdir(base):
        error(f"Папка '{base}' не найдена. Создай её и положи модель в MegixModels/<Имя>/"); return None
    model_dir = os.path.join(base, model_name)
    if not os.path.isdir(model_dir):
        subdirs = [d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d))]
        with_npz = [d for d in subdirs if any(f.endswith('.npz') for f in os.listdir(os.path.join(base, d)))]
        if not with_npz:
            error(f"В '{base}' нет моделей с .npz. Положи Megix в MegixModels/<Имя>/"); return None
        if len(with_npz) == 1:
            model_name = with_npz[0]
            model_dir = os.path.join(base, model_name)
            warning(f"'{model_name}' не найдена, использую '{model_name}'")
        else:
            print(f"{CYAN}Доступные модели:{RESET}")
            for i, d in enumerate(with_npz, 1): print(f"  {i}. {d}")
            try:
                n = input("Номер модели: ").strip()
                idx = int(n) - 1
                if 0 <= idx < len(with_npz):
                    model_name = with_npz[idx]
                    model_dir = os.path.join(base, model_name)
                else:
                    error("Неверный номер"); return None
            except (ValueError, EOFError):
                error("Отменено"); return None
    try:
        print(f"{CYAN}[AIUse] Загрузка {model_name}...{RESET}")
        m = MegixLocal(model_dir)
        print(f"{GREEN}[AIUse] {model_name} загружена ({m.arch}, {m.total_params:,} параметров){RESET}")
        _megix_cache[model_name] = m
        return m
    except Exception as e:
        error(f"Не удалось загрузить '{model_name}': {e}")
        return None

# =============== v2.35.0 HELPERS: NOTIFY / CLIPBOARD ===============
def _notify(title, text):
    try:
        if _shutil.which("termux-notification"):
            subprocess.run(["termux-notification", "--title", str(title), "--content", str(text)], timeout=5, check=False)
            return
        if _shutil.which("notify-send"):
            subprocess.run(["notify-send", str(title), str(text)], timeout=5, check=False)
            return
        if sys.platform == "darwin" and _shutil.which("osascript"):
            subprocess.run(["osascript", "-e",
                f'display notification "{text}" with title "{title}"'], timeout=5, check=False)
            return
    except Exception:
        pass
    print(f"[NOTIFY] {title}: {text}")

def _clip_set(text):
    for cmd in (["termux-clipboard-set"], ["xclip", "-selection", "clipboard"],
                ["pbcopy"], ["wl-copy"]):
        exe = _shutil.which(cmd[0])
        if exe:
            try:
                subprocess.run([exe] + cmd[1:], input=str(text).encode(), timeout=5, check=False)
                return True
            except Exception: pass
    try:
        import pyperclip
        pyperclip.copy(str(text)); return True
    except Exception: pass
    return False

def _clip_get():
    for cmd in (["termux-clipboard-get"], ["xclip", "-selection", "clipboard", "-o"],
                ["pbpaste"], ["wl-paste"]):
        exe = _shutil.which(cmd[0])
        if exe:
            try:
                out = subprocess.run([exe] + cmd[1:], capture_output=True, timeout=5, check=False)
                return out.stdout.decode('utf-8', errors='replace')
            except Exception: pass
    try:
        import pyperclip
        return pyperclip.paste() or ""
    except Exception: pass
    return ""

def _mem_info():
    try:
        import psutil
        m = psutil.virtual_memory()
        return f"Used: {m.used // (1024**2)} MB / Total: {m.total // (1024**2)} MB ({m.percent}%)"
    except ImportError:
        pass
    if os.path.exists("/proc/meminfo"):
        try:
            info = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2: info[parts[0].rstrip(":")] = int(parts[1])
            total = info.get("MemTotal", 0)
            avail = info.get("MemAvailable", info.get("MemFree", 0))
            return f"Used: {(total - avail)//1024} MB / Total: {total//1024} MB"
        except Exception: pass
    return "N/A"

# =============== AI ASYNC HELPERS ===============
def _ai_thread_start(request, max_tokens, temp, n_heads, model_name):
    handle = str(_uuid.uuid4())
    slot = {"thread": None, "result": "", "error": None, "done": threading.Event()}
    _ai_threads[handle] = slot
    def worker():
        try:
            model = get_megix_model(model_name)
            if model is None:
                slot["error"] = "модель не загружена"
                return
            mode = qwernix_variables.get("AI_Mode", "continue")
            prompt_toks = re.findall(r"<[a-z]+>|[\w]+|[.,!?;:\-]", request.lower(), flags=re.UNICODE)
            prompt = (["<user>"] + prompt_toks + ["<bot>"]) if mode == "dialog" else prompt_toks
            out = model.generate(prompt, max_tokens=max_tokens, temp=temp, n_heads=n_heads)
            text = " ".join(out).strip()
            text = re.sub(r'\s+([.,?!:;»])', r'\1', text)
            text = re.sub(r'\s+', ' ', text).strip()
            if text and text[0].isalpha(): text = text[0].upper() + text[1:]
            slot["result"] = text
        except Exception as e:
            slot["error"] = str(e)
        finally:
            slot["done"].set()
    t = threading.Thread(target=worker, daemon=True)
    slot["thread"] = t
    t.start()
    return handle

# =============== MAIN DISPATCHER ===============
def execute_qwernix_line(line, local_args=None):
    global _current_line, qwernix_traces, _sandbox_deadline, _sandbox_start, _sandbox_memory_limit

    # ===== Sandbox checks =====
    if _sandbox_deadline is not None and time.time() > _sandbox_deadline:
        raise RuntimeError(f"TimeLimit превышен ({time.time() - _sandbox_start:.1f}s)")
    if _sandbox_memory_limit is not None:
        try:
            import resource
            mem_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            mem_mb = mem_mb / (1024 * 1024) if sys.platform == "darwin" else mem_mb / 1024
            if mem_mb > _sandbox_memory_limit:
                raise RuntimeError(f"MemoryLimit ({_sandbox_memory_limit}MB) превышен")
        except ImportError:
            pass

    line = line.strip()
    if not line or line.startswith("#"): return None
    if not (line.startswith("[") and line.endswith("]")):
        error(f"Пропущена '[' или ']' -> {line}"); return None

    if line.count("[") > 1:
        blocks = extract_blocks(line)
        if len(blocks) > 1:
            for b in blocks:
                sig = execute_qwernix_line(b, local_args)
                if sig: return sig
            return None

    raw_inner = line[1:-1].strip()
    if not raw_inner: return None
    if qwernix_traces: print(f"{YELLOW}[TRACE] {raw_inner}{RESET}")

    is_func_def = raw_inner.startswith("Create Function ")

    if not is_func_def and raw_inner.startswith("While "):
        wc = raw_inner[6:].strip()
        if " Do " not in wc: error(f"Ожидалось 'Do' в While -> {raw_inner}"); return None
        cond_raw, action_raw = wc.split(" Do ", 1)
        return handle_while(cond_raw.strip(), action_raw.strip(), local_args)

    if not is_func_def and raw_inner.startswith("For "):
        fc = raw_inner[4:].strip()
        if " Do " not in fc: error(f"Ожидалось 'Do' в For -> {raw_inner}"); return None
        head, action_raw = fc.split(" Do ", 1)
        m = re.match(r'^(\w+)\s*=\s*(.+?)\s+To\s+(.+?)(?:\s+Step\s+(.+))?$', head.strip())
        if not m: error(f"For: неверный синтаксис -> {head}"); return None
        return handle_for(m.group(2), m.group(3), m.group(4), m.group(1), action_raw.strip(), local_args)

    if not is_func_def and raw_inner.startswith("ForEach "):
        fc = raw_inner[8:].strip()
        if " Do " not in fc: error(f"Ожидалось 'Do' в ForEach -> {raw_inner}"); return None
        head, action_raw = fc.split(" Do ", 1)
        m = re.match(r'^(\w+)\s+In\s+(.+)$', head.strip())
        if not m: error(f"ForEach: неверный синтаксис -> {head}"); return None
        m_var = re.match(r'^\{(\w+)\}$', m.group(2).strip()) or re.match(r'^(\w+)$', m.group(2).strip())
        if not m_var: error(f"ForEach: '{m.group(2)}' не переменная"); return None
        return handle_foreach(m.group(1), m_var.group(1), action_raw.strip(), local_args)

    if not is_func_def and raw_inner.startswith("If "):
        ifc = raw_inner[3:].strip()
        if " Then " not in ifc: error(f"Ожидалось 'Then' в If -> {raw_inner}"); return None
        cond_raw, rest = ifc.split(" Then ", 1)
        then_raw, else_raw = rest, None
        if " Else " in rest: then_raw, else_raw = rest.split(" Else ", 1)
        return handle_if(cond_raw.strip(), then_raw.strip(), else_raw.strip() if else_raw else None, local_args)

    if not is_func_def and raw_inner.startswith("Try "):
        tc = raw_inner[4:].strip()
        if " Catch " not in tc: error(f"Ожидалось 'Catch' в Try -> {raw_inner}"); return None
        try_raw, rest = tc.split(" Catch ", 1)
        finally_raw = None
        if " Finally " in rest:
            rest, finally_raw = rest.rsplit(" Finally ", 1)
        rest = rest.strip()
        if rest.startswith("Exception -> "): rest = rest[13:].strip()
        if " Then " not in rest: error(f"Ожидалось 'Then' после Catch -> {rest}"); return None
        catch_var, catch_raw = rest.split(" Then ", 1)
        return handle_try(try_raw.strip(), catch_var.strip(), catch_raw.strip(),
                          local_args, finally_raw.strip() if finally_raw else None)

    inner = substitute_args(raw_inner, local_args)
    if not is_func_def: inner = substitute_vars(inner)

    if inner == "Break": return "break"
    if inner == "Continue": return "continue"

    if inner.startswith("Throw"):
        rest = inner[5:].strip()
        if rest.startswith("(") and rest.endswith(")"):
            rest = rest[1:-1]
        msg = unquote(rest) if rest else "Исключение"
        raise RuntimeError(msg)

    if inner == "Return" or inner.startswith("Return "):
        val = inner[6:].strip() if len(inner) > 6 else ""
        if len(val) >= 2 and ((val[0] == '"' and val[-1] == '"') or (val[0] == "'" and val[-1] == "'")): val = val[1:-1]
        else:
            result = eval_arith(val)
            if result is not None: val = str(int(result)) if result == int(result) else str(result)
        return ("return", val if val else None)

    if inner.startswith("Increment "):
        name = inner[10:].strip()
        try: cur = float(qwernix_variables.get(name, 0))
        except (ValueError, TypeError): error(f"Increment: '{name}' не число"); return None
        qwernix_variables[name] = str(int(cur + 1)); return None

    if inner.startswith("Decrement "):
        name = inner[10:].strip()
        try: cur = float(qwernix_variables.get(name, 0))
        except (ValueError, TypeError): error(f"Decrement: '{name}' не число"); return None
        qwernix_variables[name] = str(int(cur - 1)); return None

    if inner.startswith("Import "):
        spec = inner[7:].strip().strip('"\' ')
        if spec.endswith("-qwnx"): return run_import_qwnx(spec[:-5], local_args)
        if spec.endswith("-py"): return run_import_py(spec[:-3])
        if spec.lower().endswith("-kit"): return run_import_kit(spec)
        return run_import_qwnx(spec, local_args)

    if inner.startswith("RunFile(") and inner.endswith(")"):
        path = inner[8:-1].strip().strip('"\' ')
        if not path.endswith(".qwnx"): path += ".qwnx"
        return run_import_qwnx(path, local_args)

    if inner.startswith("Create Function "):
        content = inner[16:].strip()
        if " Then " not in content: error(f"Ожидалось 'Then' в Create Function"); return None
        def_part, action = content.split(" Then ", 1)
        pm = re.match(r'^(\w+)\s*\(.*\)$', def_part.strip())
        fname = pm.group(1) if pm else def_part.strip()
        qwernix_custom_functions[fname] = action.strip()
        return None

    if inner.startswith("Calculate "):
        content = inner[10:].strip()
        if "=" not in content: error(f"Ожидалось '=' в Calculate"); return None
        var_name, expr = map(str.strip, content.split("=", 1))
        result = eval_arith(expr)
        if result is None: _fail(f"Calculate: '{expr}' не вычислимо")
        else: qwernix_variables[var_name] = str(int(result)) if result == int(result) else str(result)
        return None

    if inner.startswith("Set "):
        content = inner[4:].strip()
        m = re.match(r'^(\w+)\s*(\+=|-=|\*=|/=|=)\s*(.+)$', content, re.DOTALL)
        if not m: error(f"Ожидалось '=' в Set"); return None
        var_name, op, val = m.group(1), m.group(2), m.group(3).strip()
        val = unquote(val)
        if op == "=": qwernix_variables[var_name] = val
        else:
            try:
                cur = float(qwernix_variables.get(var_name, 0))
                nv = float(val)
                if op == "+=": cur += nv
                elif op == "-=": cur -= nv
                elif op == "*=": cur *= nv
                elif op == "/=": cur /= nv
                qwernix_variables[var_name] = str(int(cur)) if cur == int(cur) else str(cur)
            except (ValueError, TypeError): error(f"Set {op}: нужны числа")
        return None

    m = re.match(r'^(\w+)\((.*)\)$', inner, re.DOTALL)
    if not m: error(f"Неизвестный синтаксис -> {line}"); return None
    func_name = m.group(1)
    raw_args = m.group(2).strip()
    was_quoted = (len(raw_args) >= 2 and ((raw_args[0] == '"' and raw_args[-1] == '"') or (raw_args[0] == "'" and raw_args[-1] == "'")))
    clean_args = raw_args[1:-1] if was_quoted else raw_args

    # ============ AI (базовый) ============
    if func_name == "AIUse":
        params = {}
        left, target = split_arrow(clean_args)
        if target is None: error("AIUse требует ' -> переменная'"); return None
        for part in smart_split(left):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k.strip()] = unquote(v.strip())
        request = params.get("Request", "")
        if not request: error("AIUse: параметр Request обязателен"); return None
        model_name = params.get("Model") or qwernix_variables.get("AI_Model")
        try:
            max_tokens = int(float(params.get("MaxTokens", 40)))
            temp = float(params.get("Temp", 0.85))
        except ValueError: _fail("AIUse: MaxTokens/Temp должны быть числами"); return None
        mode = qwernix_variables.get("AI_Mode", "continue")
        try: n_heads = int(float(qwernix_variables.get("AI_Heads", 4)))
        except (ValueError, TypeError): n_heads = 4
        stream_mode = qwernix_variables.get("AI_STREAM_MODE", "off") == "on"

        model = get_megix_model(model_name)
        if model is None: return None

        prompt_toks = re.findall(r"<[a-z]+>|[\w]+|[.,!?;:\-]", request.lower(), flags=re.UNICODE)
        prompt = (["<user>"] + prompt_toks + ["<bot>"]) if mode == "dialog" else prompt_toks

        cb = None
        if stream_mode:
            def cb(tok): sys.stdout.write(tok + " "); sys.stdout.flush()

        try:
            out_toks = model.generate(prompt, max_tokens=max_tokens, temp=temp, n_heads=n_heads, callback=cb)
            if stream_mode: print()
            text = " ".join(out_toks).strip()
            text = re.sub(r'\s+([.,?!:;»])', r'\1', text)
            text = re.sub(r'«\s+', '«', text)
            text = re.sub(r'\s*-\s*', '-', text)
            text = re.sub(r'\s+', ' ', text).strip()
            if text and text[0].isalpha(): text = text[0].upper() + text[1:]
            qwernix_variables[target] = text
        except Exception as e:
            _fail(f"AIUse: генерация упала: {e}")
        return None

    if func_name == "AIThread":
        params = {}
        left, target = split_arrow(clean_args)
        if target is None: error("AIThread(Request=..., -> Handle)"); return None
        for part in smart_split(left):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k.strip()] = unquote(v.strip())
        request = params.get("Request", "")
        if not request: error("AIThread: Request обязателен"); return None
        model_name = params.get("Model") or qwernix_variables.get("AI_Model")
        try:
            max_tokens = int(float(params.get("MaxTokens", 40)))
            temp = float(params.get("Temp", 0.85))
            n_heads = int(float(qwernix_variables.get("AI_Heads", 4)))
        except ValueError: _fail("AIThread: числовые параметры некорректны"); return None
        handle = _ai_thread_start(request, max_tokens, temp, n_heads, model_name)
        qwernix_variables[target] = handle
        return None

    if func_name == "AIWait":
        args_str, target = split_arrow(clean_args)
        if target is None: error("AIWait(handle -> var)"); return None
        handle = unquote(args_str)
        slot = _ai_threads.get(handle)
        if slot is None: error(f"AIWait: handle '{handle}' не найден"); return None
        try:
            timeout = 120.0
            if not slot["done"].wait(timeout):
                error(f"AIWait: таймаут {timeout}s"); return None
            if slot["error"]:
                _fail(f"AIWait: {slot['error']}"); return None
            qwernix_variables[target] = slot["result"]
        finally:
            _ai_threads.pop(handle, None)
        return None

    if func_name == "AIStream":
        params = {}
        left, target = split_arrow(clean_args)
        if target is None: error("AIStream(Request=..., -> FullText)"); return None
        for part in smart_split(left):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k.strip()] = unquote(v.strip())
        request = params.get("Request", "")
        if not request: error("AIStream: Request обязателен"); return None
        model_name = params.get("Model") or qwernix_variables.get("AI_Model")
        try:
            max_tokens = int(float(params.get("MaxTokens", 40)))
            temp = float(params.get("Temp", 0.85))
            n_heads = int(float(qwernix_variables.get("AI_Heads", 4)))
        except ValueError: _fail("AIStream: числовые параметры некорректны"); return None
        model = get_megix_model(model_name)
        if model is None: return None
        mode = qwernix_variables.get("AI_Mode", "continue")
        prompt_toks = re.findall(r"<[a-z]+>|[\w]+|[.,!?;:\-]", request.lower(), flags=re.UNICODE)
        prompt = (["<user>"] + prompt_toks + ["<bot>"]) if mode == "dialog" else prompt_toks
        collected = []
        def cb(tok):
            collected.append(tok)
            sys.stdout.write(tok + " "); sys.stdout.flush()
        try:
            model.generate(prompt, max_tokens=max_tokens, temp=temp, n_heads=n_heads, callback=cb)
            print()
            qwernix_variables[target] = " ".join(collected)
        except Exception as e:
            _fail(f"AIStream: {e}")
        return None

    if func_name == "AIEmbed":
        text, target = split_arrow(clean_args)
        if target is None: error("AIEmbed(text -> var)"); return None
        model = get_megix_model(qwernix_variables.get("AI_Model"))
        if model is None: return None
        try:
            toks = re.findall(r"<[a-z]+>|[\w]+|[.,!?;:\-]", text.lower(), flags=re.UNICODE)
            vec = model.embed(toks)
            qwernix_variables[target] = "[" + ", ".join(f"{float(x):.4f}" for x in vec.tolist()) + "]"
        except Exception as e:
            _fail(f"AIEmbed: {e}")
        return None

    if func_name == "AIClear":
        _megix_cache.clear()
        return None

    # ============ BASE I/O ============
    if func_name == "Print":
        if was_quoted: print(clean_args)
        else: print(" ".join(unquote(p) for p in smart_split(clean_args)))
        return None
    if func_name == "Input":
        prompt, target = split_arrow(clean_args)
        if target is None: error("Input требует ' -> переменная'"); return None
        qwernix_variables[target] = input(prompt + " " if prompt else "").strip()
        return None
    if func_name == "Sleep":
        try: time.sleep(float(clean_args))
        except ValueError: error(f"Sleep: '{clean_args}' не число")
        return None
    if func_name == "Random":
        range_part, target = split_arrow(clean_args)
        if target is None: error("Random требует ' -> переменная'"); return None
        try:
            parts = split_args(range_part)
            qwernix_variables[target] = str(random.randint(int(parts[0]), int(parts[1])))
        except (ValueError, IndexError) as e: _fail(f"Random: {e}")
        return None
    if func_name == "Beep": sys.stdout.write('\a'); sys.stdout.flush(); return None
    if func_name in ("Upper", "Lower"):
        text_part, target = split_arrow(clean_args)
        if target is None: error(f"{func_name} требует ' -> переменная'"); return None
        qwernix_variables[target] = text_part.upper() if func_name == "Upper" else text_part.lower()
        return None
    if func_name == "Len":
        text_part, target = split_arrow(clean_args)
        if target is None: error("Len требует ' -> переменная'"); return None
        val = qwernix_variables.get(text_part, text_part)
        qwernix_variables[target] = str(len(val) if isinstance(val, (list, str, dict)) else len(str(val)))
        return None
    if func_name == "Clear": os.system('cls' if os.name == 'nt' else 'clear'); return None
    if func_name == "Exit":
        try: code = int(clean_args) if clean_args else 0
        except ValueError: code = 0
        sys.exit(code)
    if func_name == "Color":
        color_map = {"white": RESET, "reset": RESET, "default": RESET, "red": RED, "green": GREEN,
                     "yellow": YELLOW, "orange": YELLOW, "blue": "\033[34m", "cyan": CYAN, "magenta": "\033[35m"}
        c = clean_args.lower().strip()
        if c in color_map: sys.stdout.write(color_map[c]); sys.stdout.flush()
        else: error(f"Неизвестный цвет '{c}'")
        return None

    # ============ STRINGS ============
    if func_name == "Concat":
        parts_str, target = split_arrow(clean_args)
        if target is None: error("Concat требует ' -> переменная'"); return None
        qwernix_variables[target] = "".join(split_args(parts_str)); return None
    if func_name == "Replace":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Replace требует ' -> переменная'"); return None
        parts = split_args(args_str)
        if len(parts) != 3: error("Replace: текст, что_заменить, на_что"); return None
        qwernix_variables[target] = parts[0].replace(parts[1], parts[2]); return None
    if func_name == "Trim":
        t, target = split_arrow(clean_args)
        if target is None: error("Trim требует ' -> переменная'"); return None
        qwernix_variables[target] = t.strip(); return None
    if func_name == "Split":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Split требует ' -> переменная'"); return None
        parts = split_args(args_str)
        if len(parts) == 1: text, delim = parts[0], ","
        elif len(parts) == 2: text, delim = parts
        else: error("Split: текст, [разделитель]"); return None
        qwernix_variables[target] = text.split(delim) if delim else list(text); return None
    if func_name == "Substring":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Substring требует ' -> переменная'"); return None
        parts = split_args(args_str)
        try:
            start = int(parts[1])
            if len(parts) >= 3: qwernix_variables[target] = parts[0][start:start+int(parts[2])]
            else: qwernix_variables[target] = parts[0][start:]
        except (ValueError, IndexError): error("Substring: текст, начало, [длина]")
        return None
    if func_name == "IndexOf":
        args_str, target = split_arrow(clean_args)
        if target is None: error("IndexOf требует ' -> переменная'"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("IndexOf: текст, подстрока"); return None
        qwernix_variables[target] = str(parts[0].find(parts[1])); return None
    if func_name == "Contains":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Contains требует ' -> переменная'"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("Contains: текст, подстрока"); return None
        qwernix_variables[target] = "1" if parts[1] in parts[0] else "0"; return None
    if func_name == "Format":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Format требует ' -> переменная'"); return None
        try:
            fmt_vars = {k: (float(v) if re.match(r'^-?\d+\.?\d*$', v) else v) for k, v in qwernix_variables.items() if not isinstance(qwernix_variables[k], (list, dict))}
            qwernix_variables[target] = args_str.format(**fmt_vars)
        except Exception as e: _fail(f"Format: {e}")
        return None

    # ============ MATH ============
    if func_name in ("Abs", "Round", "Floor", "Ceil", "Sqrt", "Sin", "Cos", "Tan", "Log", "Exp"):
        args_str, target = split_arrow(clean_args)
        if target is None: error(f"{func_name} требует ' -> переменная'"); return None
        try:
            val = float(args_str)
            ops = {"Abs": abs, "Round": round, "Floor": math.floor, "Ceil": math.ceil,
                   "Sqrt": math.sqrt, "Sin": math.sin, "Cos": math.cos, "Tan": math.tan,
                   "Log": math.log, "Exp": math.exp}
            result = ops[func_name](val)
            qwernix_variables[target] = str(int(result)) if result == int(result) else str(result)
        except Exception as e: _fail(f"{func_name}: {e}")
        return None
    if func_name in ("Min", "Max"):
        args_str, target = split_arrow(clean_args)
        if target is None: error(f"{func_name} требует ' -> переменная'"); return None
        try:
            vals = [float(x) for x in split_args(args_str)]
            r = min(vals) if func_name == "Min" else max(vals)
            qwernix_variables[target] = str(int(r)) if r == int(r) else str(r)
        except (ValueError, TypeError) as e: _fail(f"{func_name}: {e}")
        return None
    if func_name in ("Pow", "Mod"):
        args_str, target = split_arrow(clean_args)
        if target is None: error(f"{func_name} требует ' -> переменная'"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error(f"{func_name}: 2 аргумента"); return None
        try:
            a, b = float(parts[0]), float(parts[1])
            r = a ** b if func_name == "Pow" else a % b
            qwernix_variables[target] = str(int(r)) if r == int(r) else str(r)
        except Exception as e: _fail(f"{func_name}: {e}")
        return None
    if func_name == "Number":
        t, target = split_arrow(clean_args)
        if target is None: error("Number требует ' -> переменная'"); return None
        try:
            v = float(t)
            qwernix_variables[target] = str(int(v)) if v == int(v) else str(v)
        except ValueError: _fail(f"Number: '{t}' не число")
        return None
    if func_name == "String":
        t, target = split_arrow(clean_args)
        if target is None: error("String требует ' -> переменная'"); return None
        qwernix_variables[target] = str(t); return None

    # ============ DICTS ============
    if func_name == "DictCreate":
        target = unquote(clean_args)
        if not target: error("DictCreate(-> var)"); return None
        qwernix_variables[target] = {}; return None
    if func_name == "DictSet":
        parts = split_args(clean_args)
        if len(parts) != 3: error("DictSet(dict, key, value)"); return None
        d = qwernix_variables.get(parts[0])
        if not isinstance(d, dict): d = {}; qwernix_variables[parts[0]] = d
        d[parts[1]] = parts[2]; return None
    if func_name == "DictGet":
        args_str, target = split_arrow(clean_args)
        if target is None: error("DictGet(dict, key -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("DictGet: 2 аргумента"); return None
        d = qwernix_variables.get(parts[0], {})
        qwernix_variables[target] = str(d.get(parts[1], "")) if isinstance(d, dict) else ""
        return None
    if func_name == "DictHas":
        args_str, target = split_arrow(clean_args)
        if target is None: error("DictHas(dict, key -> var)"); return None
        parts = split_args(args_str)
        d = qwernix_variables.get(parts[0], {})
        qwernix_variables[target] = "1" if isinstance(d, dict) and parts[1] in d else "0"
        return None
    if func_name == "DictKeys":
        args_str, target = split_arrow(clean_args)
        if target is None: error("DictKeys(dict -> var)"); return None
        d = qwernix_variables.get(unquote(args_str), {})
        qwernix_variables[target] = list(d.keys()) if isinstance(d, dict) else []
        return None
    if func_name == "DictDelete":
        parts = split_args(clean_args)
        if len(parts) != 2: error("DictDelete(dict, key)"); return None
        d = qwernix_variables.get(parts[0])
        if isinstance(d, dict): d.pop(parts[1], None)
        return None

    # ============ LISTS ============
    if func_name == "ListLength":
        args_str, target = split_arrow(clean_args)
        if target is None: error("ListLength(list -> var)"); return None
        v = qwernix_variables.get(unquote(args_str), [])
        qwernix_variables[target] = str(len(v) if isinstance(v, (list, str)) else 0)
        return None
    if func_name == "ListSort":
        v = qwernix_variables.get(unquote(clean_args))
        if isinstance(v, list): v.sort()
        return None
    if func_name == "ListReverse":
        v = qwernix_variables.get(unquote(clean_args))
        if isinstance(v, list): v.reverse()
        return None
    if func_name == "ListJoin":
        args_str, target = split_arrow(clean_args)
        if target is None: error("ListJoin(list, sep -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("ListJoin: 2 аргумента"); return None
        v = qwernix_variables.get(parts[0], [])
        qwernix_variables[target] = parts[1].join(str(x) for x in v) if isinstance(v, list) else ""
        return None
    if func_name == "ListPop":
        args_str, target = split_arrow(clean_args)
        if target is None: error("ListPop(list -> var)"); return None
        v = qwernix_variables.get(unquote(args_str))
        if isinstance(v, list) and v: qwernix_variables[target] = str(v.pop())
        else: qwernix_variables[target] = ""
        return None
    if func_name == "ListContains":
        args_str, target = split_arrow(clean_args)
        if target is None: error("ListContains(list, item -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("ListContains: 2 аргумента"); return None
        v = qwernix_variables.get(parts[0], [])
        qwernix_variables[target] = "1" if isinstance(v, list) and parts[1] in [str(x) for x in v] else "0"
        return None
    if func_name == "Get":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Get(var, idx -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("Get: 2 аргумента"); return None
        v = qwernix_variables.get(parts[0])
        if v is None: error(f"Get: '{parts[0]}' не найдена"); return None
        try:
            idx = int(parts[1])
            qwernix_variables[target] = str(v[idx]) if isinstance(v, (list, str)) else str(v)
        except (ValueError, IndexError): error(f"Get: неверный индекс '{parts[1]}'")
        return None
    if func_name == "Push":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Push(value, list)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("Push: 2 аргумента"); return None
        lst = qwernix_variables.get(target)
        if not isinstance(lst, list): lst = []; qwernix_variables[target] = lst
        lst.append(parts[0]); return None

    # ============ FILES ============
    if func_name == "FileRead":
        t, target = split_arrow(clean_args)
        if target is None: error("FileRead(path -> var)"); return None
        try:
            with open(t, 'r', encoding='utf-8') as f: qwernix_variables[target] = f.read()
        except Exception as e: _fail(f"FileRead: {e}")
        return None
    if func_name == "FileWrite":
        parts = split_args(clean_args)
        if len(parts) != 2: error("FileWrite(path, text)"); return None
        try:
            with open(parts[0], 'w', encoding='utf-8') as f: f.write(parts[1])
        except Exception as e: _fail(f"FileWrite: {e}")
        return None
    if func_name == "FileAppend":
        parts = split_args(clean_args)
        if len(parts) != 2: error("FileAppend(path, text)"); return None
        try:
            with open(parts[0], 'a', encoding='utf-8') as f: f.write(parts[1])
        except Exception as e: _fail(f"FileAppend: {e}")
        return None
    if func_name in ("FileExists", "DirExists"):
        args_str, target = split_arrow(clean_args)
        if target is None: error(f"{func_name}(path -> var)"); return None
        qwernix_variables[target] = "1" if (os.path.isfile(args_str) if func_name == "FileExists" else os.path.isdir(args_str)) else "0"
        return None
    if func_name == "FileDelete":
        try: os.remove(unquote(clean_args))
        except Exception as e: _fail(f"FileDelete: {e}")
        return None
    if func_name == "DirCreate":
        try: os.makedirs(unquote(clean_args), exist_ok=True)
        except Exception as e: _fail(f"DirCreate: {e}")
        return None
    if func_name == "DirDelete":
        try: os.rmdir(unquote(clean_args))
        except Exception as e: _fail(f"DirDelete: {e}")
        return None
    if func_name == "DirList":
        args_str, target = split_arrow(clean_args)
        if target is None: error("DirList(path -> var)"); return None
        try: qwernix_variables[target] = os.listdir(args_str)
        except Exception as e: _fail(f"DirList: {e}")
        return None
    if func_name == "PathJoin":
        args_str, target = split_arrow(clean_args)
        if target is None: error("PathJoin(a, b -> var)"); return None
        try: qwernix_variables[target] = os.path.join(*split_args(args_str))
        except Exception as e: _fail(f"PathJoin: {e}")
        return None
    if func_name == "PathBase":
        args_str, target = split_arrow(clean_args)
        if target is None: error("PathBase(path -> var)"); return None
        qwernix_variables[target] = os.path.basename(args_str); return None
    if func_name == "PathExt":
        args_str, target = split_arrow(clean_args)
        if target is None: error("PathExt(path -> var)"); return None
        qwernix_variables[target] = os.path.splitext(args_str)[1]; return None

    # ============ SYSTEM ============
    if func_name == "OsName":
        _, target = split_arrow(clean_args)
        if target is None: error("OsName(-> var)"); return None
        qwernix_variables[target] = os.name; return None
    if func_name == "Platform":
        _, target = split_arrow(clean_args)
        if target is None: error("Platform(-> var)"); return None
        qwernix_variables[target] = sys.platform; return None
    if func_name == "IsAndroid":
        _, target = split_arrow(clean_args)
        if target is None: error("IsAndroid(-> var)"); return None
        qwernix_variables[target] = "1" if (sys.platform == "linux" and os.path.exists("/system/build.prop")) else "0"; return None
    if func_name == "OsGetEnv":
        args_str, target = split_arrow(clean_args)
        if target is None: error("OsGetEnv(name -> var)"); return None
        qwernix_variables[target] = os.environ.get(args_str, ""); return None
    if func_name == "OsSetEnv":
        parts = split_args(clean_args)
        if len(parts) != 2: error("OsSetEnv(name, value)"); return None
        os.environ[parts[0]] = parts[1]; return None
    if func_name == "ShellRun":
        args_str, target = split_arrow(clean_args)
        try:
            r = subprocess.check_output(args_str, shell=True, stderr=subprocess.STDOUT).decode('utf-8', errors='ignore')
            if target: qwernix_variables[target] = r
            else: print(r)
        except Exception as e: _fail(f"ShellRun: {e}")
        return None

    # ============ JSON / REGEX / TIME / DEBUG ============
    if func_name == "JsonEncode":
        args_str, target = split_arrow(clean_args)
        if target is None: error("JsonEncode(var -> json_str)"); return None
        import json
        try: qwernix_variables[target] = json.dumps(qwernix_variables.get(args_str, args_str), ensure_ascii=False)
        except Exception as e: _fail(f"JsonEncode: {e}")
        return None
    if func_name == "JsonDecode":
        args_str, target = split_arrow(clean_args)
        if target is None: error("JsonDecode(json_str -> var)"); return None
        import json
        try: qwernix_variables[target] = json.loads(args_str)
        except Exception as e: _fail(f"JsonDecode: {e}")
        return None
    if func_name == "RegexMatch":
        args_str, target = split_arrow(clean_args)
        if target is None: error("RegexMatch(pattern, text -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("RegexMatch: 2 аргумента"); return None
        try:
            m = re.search(parts[0], parts[1])
            qwernix_variables[target] = m.group(0) if m else ""
        except re.error as e: _fail(f"RegexMatch: {e}")
        return None
    if func_name == "RegexReplace":
        args_str, target = split_arrow(clean_args)
        if target is None: error("RegexReplace(pattern, repl, text -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 3: error("RegexReplace: 3 аргумента"); return None
        try: qwernix_variables[target] = re.sub(parts[0], parts[1], parts[2])
        except re.error as e: _fail(f"RegexReplace: {e}")
        return None
    if func_name == "RegexFindAll":
        args_str, target = split_arrow(clean_args)
        if target is None: error("RegexFindAll(pattern, text -> var)"); return None
        parts = split_args(args_str)
        if len(parts) != 2: error("RegexFindAll: 2 аргумента"); return None
        try: qwernix_variables[target] = re.findall(parts[0], parts[1])
        except re.error as e: _fail(f"RegexFindAll: {e}")
        return None
    if func_name == "Now":
        _, target = split_arrow(clean_args)
        if target is None: error("Now(-> var)"); return None
        qwernix_variables[target] = time.strftime("%Y-%m-%d %H:%M:%S"); return None
    if func_name == "NowUnix":
        _, target = split_arrow(clean_args)
        if target is None: error("NowUnix(-> var)"); return None
        qwernix_variables[target] = str(int(time.time())); return None
    if func_name == "Timer":
        args_str, target = split_arrow(clean_args)
        name = unquote(args_str)
        if target is None: qwernix_timers[name] = time.time(); return None
        if name not in qwernix_timers: error(f"Timer '{name}': не запущен"); return None
        qwernix_variables[target] = f"{time.time() - qwernix_timers[name]:.3f}"; return None
    if func_name == "Debug":
        var = unquote(clean_args)
        print(f"[DEBUG] {var} = {qwernix_variables.get(var, '<undefined>')}"); return None
    if func_name == "TraceOn": globals()['qwernix_traces'] = True; return None
    if func_name == "TraceOff": globals()['qwernix_traces'] = False; return None
    if func_name == "AssertEqual":
        args_str, msg = split_arrow(clean_args)
        parts = split_args(args_str)
        if len(parts) != 2: error("AssertEqual(a, b -> msg)"); return None
        if parts[0] != parts[1]: error(f"AssertEqual провален: {parts[0]} != {parts[1]} {msg or ''}"); sys.exit(1)
        return None
    if func_name == "Assert":
        cond_str, msg = split_arrow(clean_args)
        if not evaluate_condition(substitute_vars(cond_str)): error(f"Assert провален: {msg or cond_str}"); sys.exit(1)
        return None
    if func_name == "Help": print_help(); return None
    if func_name == "Call":
        args_str, target = split_arrow(clean_args)
        if target is None: error("Call(fn(args) -> var)"); return None
        m_inner = re.match(r'^(\w+)\((.*)\)$', args_str, re.DOTALL)
        if not m_inner: error(f"Call: неверный синтаксис '{args_str}'"); return None
        inner_fn = m_inner.group(1)
        inner_args = m_inner.group(2).strip()
        parsed = split_args(inner_args) if inner_args else []
        if inner_fn not in qwernix_custom_functions: error(f"Функция '{inner_fn}' не определена"); return None
        sig = execute_qwernix_block(qwernix_custom_functions[inner_fn], parsed)
        if isinstance(sig, tuple) and sig[0] == "return": qwernix_variables[target] = str(sig[1]) if sig[1] is not None else ""
        else: qwernix_variables[target] = ""
        return None
    if func_name in qwernix_custom_functions:
        parsed = split_args(clean_args) if clean_args else []
        return execute_qwernix_block(qwernix_custom_functions[func_name], parsed)

    # ============ v2.35.0: NETWORK / HTTP ============
    if func_name in ("HttpGet", "HttpsGet"):
        url, target = split_arrow(clean_args)
        if target is None: error(f"{func_name}(url -> var)"); return None
        try:
            with _urlopen(unquote(url), timeout=30) as r:
                qwernix_variables[target] = r.read().decode('utf-8', errors='replace')
        except Exception as e: _fail(f"{func_name}: {e}")
        return None
    if func_name == "HttpPost":
        args_str, target = split_arrow(clean_args)
        parts = split_args(args_str)
        if target is None or len(parts) < 2: error("HttpPost(url, body -> var)"); return None
        try:
            data = parts[1].encode('utf-8')
            req = _urlRequest(parts[0], data=data, method='POST',
                              headers={'Content-Type': 'text/plain; charset=utf-8'})
            with _urlopen(req, timeout=30) as r:
                qwernix_variables[target] = r.read().decode('utf-8', errors='replace')
        except Exception as e: _fail(f"HttpPost: {e}")
        return None
    if func_name == "HttpDownload":
        parts = split_args(clean_args)
        if len(parts) != 2: error("HttpDownload(url, path)"); return None
        try: _urlretrieve(parts[0], parts[1])
        except Exception as e: _fail(f"HttpDownload: {e}")
        return None
    if func_name == "UrlEncode":
        text, target = split_arrow(clean_args)
        if target is None: error("UrlEncode(text -> var)"); return None
        qwernix_variables[target] = _urlquote(text, safe='')
        return None
    if func_name == "UrlDecode":
        text, target = split_arrow(clean_args)
        if target is None: error("UrlDecode(text -> var)"); return None
        qwernix_variables[target] = _urlunquote(text)
        return None

    # ============ v2.35.0: CRYPTO ============
    if func_name == "Base64Encode":
        text, target = split_arrow(clean_args)
        if target is None: error("Base64Encode(text -> var)"); return None
        qwernix_variables[target] = _b64.b64encode(text.encode('utf-8')).decode()
        return None
    if func_name == "Base64Decode":
        text, target = split_arrow(clean_args)
        if target is None: error("Base64Decode(b64 -> var)"); return None
        try:
            qwernix_variables[target] = _b64.b64decode(text.encode()).decode('utf-8', errors='replace')
        except Exception as e: _fail(f"Base64Decode: {e}")
        return None
    if func_name in ("HashMD5", "HashSHA256"):
        text, target = split_arrow(clean_args)
        if target is None: error(f"{func_name}(text -> var)"); return None
        h = _hashlib.md5() if func_name == "HashMD5" else _hashlib.sha256()
        h.update(text.encode('utf-8'))
        qwernix_variables[target] = h.hexdigest()
        return None
    if func_name == "Uuid":
        _, target = split_arrow(clean_args)
        if target is None: error("Uuid(-> var)"); return None
        qwernix_variables[target] = str(_uuid.uuid4())
        return None

    # ============ v2.35.0: STRINGS (extended) ============
    if func_name == "StartsWith":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("StartsWith(text, prefix -> var)"); return None
        qwernix_variables[target] = "1" if parts[0].startswith(parts[1]) else "0"
        return None
    if func_name == "EndsWith":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("EndsWith(text, suffix -> var)"); return None
        qwernix_variables[target] = "1" if parts[0].endswith(parts[1]) else "0"
        return None
    if func_name in ("PadLeft", "PadRight"):
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) < 2: error(f"{func_name}(text, len, [char] -> var)"); return None
        fill = parts[2] if len(parts) > 2 else " "
        n = int(parts[1])
        qwernix_variables[target] = parts[0].rjust(n, fill[0]) if func_name == "PadLeft" else parts[0].ljust(n, fill[0])
        return None
    if func_name == "SplitLines":
        text, target = split_arrow(clean_args)
        if target is None: error("SplitLines(text -> var)"); return None
        qwernix_variables[target] = text.splitlines()
        return None
    if func_name == "Repeat":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("Repeat(text, n -> var)"); return None
        qwernix_variables[target] = parts[0] * int(parts[1])
        return None
    if func_name == "CharAt":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("CharAt(text, idx -> var)"); return None
        try: qwernix_variables[target] = parts[0][int(parts[1])]
        except IndexError: qwernix_variables[target] = ""
        return None

    # ============ v2.35.0: LISTS (extended) ============
    if func_name == "ListSlice":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) < 3: error("ListSlice(list, start, end -> var)"); return None
        v = qwernix_variables.get(parts[0])
        if not isinstance(v, list): error(f"ListSlice: '{parts[0]}' не список"); return None
        qwernix_variables[target] = v[int(parts[1]):int(parts[2])]
        return None
    if func_name == "ListConcat":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("ListConcat(a, b -> var)"); return None
        a, b = qwernix_variables.get(parts[0], []), qwernix_variables.get(parts[1], [])
        if not isinstance(a, list) or not isinstance(b, list): error("ListConcat: не списки"); return None
        qwernix_variables[target] = a + b
        return None
    if func_name == "ListUnique":
        lst_name, target = split_arrow(clean_args)
        if target is None: error("ListUnique(list -> var)"); return None
        v = qwernix_variables.get(unquote(lst_name))
        if not isinstance(v, list): error("ListUnique: не список"); return None
        seen = set(); out = []
        for x in v:
            key = str(x)
            if key not in seen:
                seen.add(key); out.append(x)
        qwernix_variables[target] = out
        return None
    if func_name == "ListIndex":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("ListIndex(list, item -> var)"); return None
        v = qwernix_variables.get(parts[0], [])
        qwernix_variables[target] = str(v.index(parts[1])) if isinstance(v, list) and parts[1] in v else "-1"
        return None

    # ============ v2.35.0: MATH (extended) ============
    if func_name == "Clamp":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 3: error("Clamp(val, min, max -> var)"); return None
        x, lo, hi = float(parts[0]), float(parts[1]), float(parts[2])
        r = max(lo, min(hi, x))
        qwernix_variables[target] = str(int(r)) if r == int(r) else str(r)
        return None
    if func_name == "Sign":
        val, target = split_arrow(clean_args)
        if target is None: error("Sign(x -> var)"); return None
        qwernix_variables[target] = str((float(val) > 0) - (float(val) < 0))
        return None
    if func_name == "Atan2":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("Atan2(y, x -> var)"); return None
        qwernix_variables[target] = str(math.atan2(float(parts[0]), float(parts[1])))
        return None
    if func_name == "Lerp":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 3: error("Lerp(a, b, t -> var)"); return None
        a, b, t = float(parts[0]), float(parts[1]), float(parts[2])
        qwernix_variables[target] = str(a + (b - a) * t)
        return None

    # ============ v2.35.0: DATES ============
    if func_name == "DateAdd":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("DateAdd(date, days -> var)"); return None
        try:
            d = _datetime.strptime(parts[0], "%Y-%m-%d")
            qwernix_variables[target] = (d + _timedelta(days=int(parts[1]))).strftime("%Y-%m-%d")
        except Exception as e: _fail(f"DateAdd: {e}")
        return None
    if func_name == "DateDiff":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("DateDiff(d1, d2 -> var)"); return None
        try:
            d1 = _datetime.strptime(parts[0], "%Y-%m-%d")
            d2 = _datetime.strptime(parts[1], "%Y-%m-%d")
            qwernix_variables[target] = str(abs((d2 - d1).days))
        except Exception as e: _fail(f"DateDiff: {e}")
        return None
    if func_name == "FormatDate":
        ps, target = split_arrow(clean_args)
        parts = split_args(ps)
        if target is None or len(parts) != 2: error("FormatDate(date, fmt -> var)"); return None
        try:
            d = _datetime.strptime(parts[0], "%Y-%m-%d")
            fmt = parts[1].replace("DD", "%d").replace("MM", "%m").replace("YYYY", "%Y")
            qwernix_variables[target] = d.strftime(fmt)
        except Exception as e: _fail(f"FormatDate: {e}")
        return None

    # ============ v2.35.0: FILES (extended) ============
    if func_name == "FileCopy":
        parts = split_args(clean_args)
        if len(parts) != 2: error("FileCopy(src, dst)"); return None
        try: _shutil.copy2(parts[0], parts[1])
        except Exception as e: _fail(f"FileCopy: {e}")
        return None
    if func_name == "FileMove":
        parts = split_args(clean_args)
        if len(parts) != 2: error("FileMove(src, dst)"); return None
        try: _shutil.move(parts[0], parts[1])
        except Exception as e: _fail(f"FileMove: {e}")
        return None
    if func_name == "FileSize":
        path, target = split_arrow(clean_args)
        if target is None: error("FileSize(path -> var)"); return None
        try: qwernix_variables[target] = str(os.path.getsize(unquote(path)))
        except Exception as e: _fail(f"FileSize: {e}")
        return None
    if func_name == "FileIsEmpty":
        path, target = split_arrow(clean_args)
        if target is None: error("FileIsEmpty(path -> var)"); return None
        try: qwernix_variables[target] = "1" if os.path.getsize(unquote(path)) == 0 else "0"
        except Exception as e: _fail(f"FileIsEmpty: {e}")
        return None

    # ============ v2.35.0: SYSTEM (extended) ============
    if func_name == "CpuCount":
        _, target = split_arrow(clean_args)
        if target is None: error("CpuCount(-> var)"); return None
        qwernix_variables[target] = str(os.cpu_count() or 1)
        return None
    if func_name == "MemInfo":
        _, target = split_arrow(clean_args)
        if target is None: error("MemInfo(-> var)"); return None
        qwernix_variables[target] = _mem_info()
        return None
    if func_name == "Notify":
        parts = split_args(clean_args)
        if len(parts) != 2: error("Notify(title, text)"); return None
        _notify(parts[0], parts[1])
        return None
    if func_name == "ClipSet":
        _clip_set(unquote(clean_args))
        return None
    if func_name == "ClipGet":
        _, target = split_arrow(clean_args)
        if target is None: error("ClipGet(-> var)"); return None
        qwernix_variables[target] = _clip_get()
        return None

    # ============ v2.35.0: SANDBOX ============
    if func_name == "TimeLimit":
        try:
            sec = float(clean_args)
            _sandbox_start = time.time()
            _sandbox_deadline = _sandbox_start + sec
        except ValueError: error("TimeLimit: не число")
        return None
    if func_name == "MemoryLimit":
        try: _sandbox_memory_limit = float(clean_args)
        except ValueError: error("MemoryLimit: не число")
        return None

    error(f"Неизвестная функция '{func_name}'")
    return None

# =============== HELP ===============
def print_help():
    print(f"""{CYAN}Qwernix Help — {qwernix_variables['Execution_Qwernix_Ver']}{RESET}
База: [Set X = 5] [+=/-=/*=//=] [Calculate] [Increment/Decrement]
      [Print] [Input -> var] [Sleep] [Beep] [Clear] [Exit [code]] [Color(name)]
Контроль: [If cond Then ... Else ...] [While cond Do ...]
          [For i = 1 To 10 [Step N] Do ...] [ForEach item In {{list}} Do ...]
          [Break] [Continue] [Return value] [Throw("msg")]
          [Try ... Catch Exception -> e Then ... Finally ...]
Функции: [Create Function f() Then ...] [Call(f(args) -> r)]
AI: [AIUse(Request=..., Model=..., MaxTokens=40, Temp=0.85, -> var)]
    [AIThread(...->H)] [AIWait(H->r)] [AIStream(...->t)] [AIEmbed(t->v)] [AIClear()]
    [Set AI_Model=..] [Set AI_Mode=continue|dialog] [Set AI_Heads=4] [Set AI_STREAM_MODE=on|off]
Импорты: [Import x-qwnx] [Import x-py] [Import Base-Kit] [Import System-Kit] [Import Files-Kit] [Import All-Kit]
Строки: Upper Lower Len Trim Replace Split Substring IndexOf Contains Concat Format
        StartsWith EndsWith PadLeft PadRight SplitLines Repeat CharAt
Математика: Abs Round Floor Ceil Sqrt Sin Cos Tan Log Exp Min Max Pow Mod Random
            Clamp Sign Atan2 Lerp
Списки: [Split->L] [Get(L,0->x)] [Push(x->L)] [ListLength/Sort/Reverse/Join/Pop/Contains]
        [ListSlice/Concat/Unique/Index]
Словари: [DictCreate(->d)] [DictSet(d,k,v)] [DictGet(d,k->v)] [DictHas/Keys/Delete]
Сеть: HttpGet HttpPost HttpDownload UrlEncode UrlDecode
Крипто: Base64Encode Base64Decode HashMD5 HashSHA256 Uuid
Даты: DateAdd DateDiff FormatDate
Файлы (ext): FileCopy FileMove FileSize FileIsEmpty
Система (ext): CpuCount MemInfo Notify ClipSet ClipGet
Sandbox: TimeLimit(sec) MemoryLimit(MB)
Файлы: FileRead/Write/Append/Exists/Delete DirCreate/Exists/List/Delete PathJoin/Base/Ext
Система: OsName Platform IsAndroid OsGetEnv OsSetEnv ShellRun
JSON: JsonEncode JsonDecode   Regex: RegexMatch/Replace/FindAll   Время: Now NowUnix
Отладка: Debug TraceOn TraceOff Assert AssertEqual
Прочее: RunFile(path.qwnx) Timer(name) Timer(name -> t) Help
Константы: TRUE FALSE PI E VERSION SCRIPT_VERSION OS_ARCH Execution_Qwernix_Ver Iteration_Limit
""")

# =============== ENTRY POINT ===============
def run_qwernix_file(file_path):
    global _current_line
    if not os.path.exists(file_path): error(f"Файл '{file_path}' не найден"); return
    print(f"{CYAN}--- Запуск Qwernix v2.35.0: {file_path} ---{RESET}")
    with open(file_path, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f, 1):
            _current_line = i
            try: execute_qwernix_line(line)
            except SystemExit: raise
            except Exception as e: error(f"Неперехваченная ошибка: {e}")

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "main.qwnx"
    run_qwernix_file(target)